﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class UserCrud
    {
        public string username { set; get; }
        public string password { set; get; }
    }
}
